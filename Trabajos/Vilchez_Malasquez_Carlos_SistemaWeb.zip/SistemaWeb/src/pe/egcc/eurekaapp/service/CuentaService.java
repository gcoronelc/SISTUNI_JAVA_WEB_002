package pe.egcc.eurekaapp.service;

import java.util.List;
import java.util.Map;
import pe.egcc.eurekaapp.dao.espec.CuentaDaoEspec;
import pe.egcc.eurekaapp.dao.impl.CuentaDaoImpl;
import pe.egcc.eurekaapp.domain.ClienteBean;

/**
 *
 * @author Gustavo Coronel
 */
public class CuentaService {
  
  
  public void registrarDeposito(String paterno, String materno,String nombres, String dni,
		  						String fecha,String direccion, String telefono, String grado, 
		  						String seccion){
    /*if(paterno == null || paterno.isEmpty()){
      throw new RuntimeException("La cuenta no puede estar vacía.");
    }*/

    CuentaDaoEspec cuentaDao;
    cuentaDao = new CuentaDaoImpl();
    cuentaDao.registrarDeposito(paterno, materno, nombres, dni, fecha,
				direccion, telefono, grado, seccion);
  }
  
  public void registrarSecundaria(String paterno, String materno,String nombres, String dni,
			String fecha,String direccion, String telefono, String grado, 
			String seccion){
	  
	  CuentaDaoEspec cuentaDao;
	  cuentaDao = new CuentaDaoImpl();
	  cuentaDao.registrarSecundaria(paterno, materno, nombres, dni, fecha,
      direccion, telefono, grado, seccion);
  }
  
  
  public List<Map<String, ?>> obtenerMovimientos(String cuenta) {
    CuentaDaoEspec cuentaDao;
    cuentaDao = new CuentaDaoImpl();
    return cuentaDao.obtenerMovimientos(cuenta);
  }
  
  public List<Map<String, ?>> obtenerClientes(String paterno, String materno, String nombres) {
	    CuentaDaoEspec cuentaDao;
	    cuentaDao = new CuentaDaoImpl();
	    return cuentaDao.obtenerClientes(paterno, materno, nombres);
  }
  
  
  public List<Map<String, ?>> obtenerSecundaria(String paterno, String materno, String nombres) {
	    CuentaDaoEspec cuentaDao;
	    cuentaDao = new CuentaDaoImpl();
	    return cuentaDao.obtenerSecundaria(paterno, materno, nombres);
}
  /*
  public List<ClienteBean> getClientes(ClienteBean bean) {
	    return cuentaDao.readForCriteria(bean);
 }*/
  
  /*public List<Map<String, ?>> obtenerClientes() {
	    CuentaDaoEspec cuentaDao;
	    cuentaDao = new CuentaDaoImpl();
	    return cuentaDao.obtenerClientes();
}*/
}
