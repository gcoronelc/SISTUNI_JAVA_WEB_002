package pe.egcc.eureka.dao.espec;

import pe.egcc.eureka.domain.Cliente;

/**
 *
 * @author Gustavo Coronel
 */
public interface DaoClienteEspec extends DaoCrudEspec<Cliente>{

	void cambiarClave(String usuario, String clave);
}
