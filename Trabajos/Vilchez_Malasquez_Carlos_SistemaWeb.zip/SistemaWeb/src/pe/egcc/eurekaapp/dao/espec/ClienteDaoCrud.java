package pe.egcc.eurekaapp.dao.espec;

import pe.egcc.eurekaapp.domain.ClienteBean;

/**
 *
 * @author Gustavo Coronel
 */
public interface ClienteDaoCrud extends AbstractCrud<ClienteBean>{
  
}
