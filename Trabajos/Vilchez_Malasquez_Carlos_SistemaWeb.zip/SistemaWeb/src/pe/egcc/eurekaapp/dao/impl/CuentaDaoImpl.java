package pe.egcc.eurekaapp.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import pe.egcc.eurekaapp.dao.espec.CuentaDaoEspec;
import pe.egcc.eurekaapp.db.AccesoDB;
import pe.egcc.eurekaapp.domain.ClienteBean;

/**
 *
 * @author GustavoCoronel
 */
public class CuentaDaoImpl implements CuentaDaoEspec {

  @Override
  public void registrarDeposito(String paterno, String materno,String nombres, String dni,
							    String fecha,String direccion, String telefono, String grado, 
			                    String seccion) {
    Connection cn = null;
    try {
    	//Acceso al objecto Connection
        cn = AccesoDB.getConnection();
        //Inicia Tx
        cn.setAutoCommit(false);
        // Incrementar el contador
        String sql = "update contador " +
                    "set int_contitem  = int_contitem + 1 " +
                    "where vch_conttabla  = 'Primaria' ";
        PreparedStatement pstm = cn.prepareStatement(sql);
        int filas = pstm.executeUpdate();
        pstm.close();
        if (filas == 0){
            throw new Exception("Contador no existe.");
        }
        
        // Leer contador
        sql =   "select int_contitem, int_contlongitud "
                + "from contador "
                + "where vch_conttabla = 'Primaria' ";
        pstm = cn.prepareStatement(sql);
        ResultSet rs = pstm.executeQuery();
        rs.next();
        int cont = rs.getInt("int_contitem");
        int size = rs.getInt("int_contlongitud");
        
        // Crear Codigo
        
        String formato = "%1$0" + size + "d";
        String codigo = String.format(formato,cont);
        
        
        // Insertar Cliente
         sql = "insert into primaria(chr_pricodigo, vch_pripaterno, "
          + "vch_primaterno, vch_prinombre, "
          + "chr_pridni, vch_prifechamat, "
          + "vch_pridireccion, vch_pritelefono, chr_prigrado, "
          + "chr_priseccion) "
          + "values(?,?,?,?,?,?,?,?,?,?)";
  
        pstm = cn.prepareStatement(sql);
        pstm.setString(1,  codigo);
        pstm.setString(2,  paterno);
        pstm.setString(3,  materno);
        pstm.setString(4,  nombres);
        pstm.setString(5,  dni);
        pstm.setString(6,  fecha);
        pstm.setString(7,  direccion);
        pstm.setString(8,  telefono);
        pstm.setString(9,  grado);
        pstm.setString(10, seccion);
        pstm.executeUpdate();
        pstm.close();
        
        //bean.setCodigo(codigo);
        ////////////////////////////////
        
        //Confirma Tx
        cn.commit();
        
    }catch(Exception e){
        try{
            cn.rollback();
        }catch(Exception e1){
            
        }
        String mensaje = "Error en el Proceso.";
        if(e.getMessage() !=  null && !e.getMessage().isEmpty() ){
            mensaje += " " + e.getMessage();
        }
        throw new RuntimeException(mensaje);
    }finally{
        try {
            cn.close();
        } catch (Exception e) {
          }
      }
    
  }
  
  @Override
  public void registrarSecundaria(String paterno, String materno,String nombres, String dni,
							    String fecha,String direccion, String telefono, String grado, 
			                    String seccion) {
	  Connection cn = null;
      try{
          //Acceso al objecto Connection
          cn = AccesoDB.getConnection();
          //Inicia Tx
          cn.setAutoCommit(false);
          // Incrementar el contador
          String sql = "update contador " +
                      "set int_contitem  = int_contitem + 1 " +
                      "where vch_conttabla  = 'Secundaria' ";
          PreparedStatement pstm = cn.prepareStatement(sql);
          int filas = pstm.executeUpdate();
          pstm.close();
          if (filas == 0){
              throw new Exception("Contador no existe.");
          }
          
          // Leer contador
          sql =   "select int_contitem, int_contlongitud "
                  + "from contador "
                  + "where vch_conttabla = 'Secundaria' ";
          pstm = cn.prepareStatement(sql);
          ResultSet rs = pstm.executeQuery();
          rs.next();
          int cont = rs.getInt("int_contitem");
          int size = rs.getInt("int_contlongitud");
          
          // Crear Codigo
          
          String formato = "%1$0" + size + "d";
          String codigo = String.format(formato,cont);
          
          // Insertar Cliente
          sql = "insert into secundaria(chr_seccodigo, vch_secpaterno, "
            + "vch_secmaterno, vch_secnombre, "
            + "chr_secdni, vch_secfechamat, "
            + "vch_secdireccion, vch_sectelefono, chr_secgrado, "
            + "chr_secseccion) "
            + "values(?,?,?,?,?,?,?,?,?,?)";
          
          pstm = cn.prepareStatement(sql);
          pstm.setString(1,  codigo);
          pstm.setString(2,  paterno);
          pstm.setString(3,  materno);
          pstm.setString(4,  nombres);
          pstm.setString(5,  dni);
          pstm.setString(6,  fecha);
          pstm.setString(7,  direccion);
          pstm.setString(8,  telefono);
          pstm.setString(9,  grado);
          pstm.setString(10, seccion);
          pstm.executeUpdate();
          pstm.close();
          
          
          ////////////////////////////////
          
          //Confirma Tx
          cn.commit();
          
      }catch(Exception e){
          try{
              cn.rollback();
          }catch(Exception e1){
              
          }
          String mensaje = "Error en el Proceso.";
          if(e.getMessage() !=  null && !e.getMessage().isEmpty() ){
              mensaje += " " + e.getMessage();
          }
          throw new RuntimeException(mensaje);
      }finally{
          try {
              cn.close();
          } catch (Exception e) {
            }
        }
    
  }

  @Override
  public List<Map<String, ?>> obtenerMovimientos(String cuenta) {
    List<Map<String, ?>> lista = new ArrayList<>();
    Connection cn = null;
    try {
      cn = AccesoDB.getConnection();
      String sql = "select "
              + "CUENCODIGO, MONENOMBRE, CUENSALDO, "
              + "CUENESTADO, MOVINUMERO, MOVIFECHA, "
              + "MOVIIMPORTE, TIPOCODIGO, TIPONOMBRE "
              + "from v_movimiento "
              + "where CUENCODIGO = ?";
      PreparedStatement pstm = cn.prepareStatement(sql);
      pstm.setString(1, cuenta);
      ResultSet rs = pstm.executeQuery();
      while(rs.next()){
        Map<String,Object> rec = new HashMap<>();
        rec.put("CUENCODIGO", rs.getString("CUENCODIGO"));
        rec.put("MONENOMBRE", rs.getString("MONENOMBRE"));
        rec.put("CUENSALDO", rs.getDouble("CUENSALDO"));
        rec.put("CUENESTADO", rs.getString("CUENESTADO"));
        rec.put("MOVINUMERO", rs.getInt("MOVINUMERO"));
        rec.put("MOVIFECHA", rs.getTimestamp("MOVIFECHA"));
        rec.put("MOVIIMPORTE", rs.getDouble("MOVIIMPORTE"));
        rec.put("TIPOCODIGO", rs.getString("TIPOCODIGO"));
        rec.put("TIPONOMBRE", rs.getString("TIPONOMBRE"));
        lista.add(rec);
      }
      rs.close();
      pstm.close();
    } catch (SQLException e) {
      throw new RuntimeException(e.getMessage());
    } catch (Exception e) {
      e.printStackTrace();
      String msg = "Error en el proceso de validación.";
      if (e.getMessage() != null) {
        msg += "\n" + e.getMessage();
      }
      throw new RuntimeException(msg);
    } finally {
      try {
        cn.close();
      } catch (Exception e) {
      }
    }

    return lista;
  }
  
  @Override
  public List<Map<String, ?>> obtenerClientes(String paterno, String materno, String nombres) {
	  List<Map<String, ?>> lista = new ArrayList<>();
	    Connection cn = null;
	    paterno +="%";
	    materno +="%";
	    nombres +="%";
	    try {
	      cn = AccesoDB.getConnection();
	      /*String sql = "select "
	              + "CUENCODIGO, MONENOMBRE, CUENSALDO, "
	              + "CUENESTADO, MOVINUMERO, MOVIFECHA, "
	              + "MOVIIMPORTE, TIPOCODIGO, TIPONOMBRE "
	              + "from v_movimiento "
	              + "where CUENCODIGO = ?";*/
	      /*String sql = "select chr_cliecodigo, vch_cliepaterno, "
	              + "vch_cliematerno, vch_clienombre, "
	              + "chr_cliedni, vch_clieciudad, "
	              + "vch_cliedireccion, vch_clietelefono, vch_clieemail "
	              + "from cliente "
	      		  + "where vch_cliepaterno like ? "
	              + "and vch_cliematerno like ? "
	              + "and vch_clienombre like ?";*/
	      String sql = "select chr_pricodigo, vch_pripaterno, "
                  + "vch_primaterno, vch_prinombre, "
                  + "chr_pridni, vch_prifechamat, "
                  + "vch_pridireccion, vch_pritelefono, chr_prigrado, "
                  + "chr_priseccion "
                  + "from primaria "
                  + "where vch_pripaterno like ? "
                  + "and vch_primaterno like ? "
                  + "and vch_prinombre like ?";
	      PreparedStatement pstm = cn.prepareStatement(sql);
	      pstm.setString(1, paterno);
	      pstm.setString(2, materno);
	      pstm.setString(3, nombres);
	      ResultSet rs = pstm.executeQuery();
	      while(rs.next()){
	        Map<String,Object> rec = new HashMap<>();
	        rec.put("chr_pricodigo", rs.getString("chr_pricodigo"));
	        rec.put("vch_pripaterno", rs.getString("vch_pripaterno"));
	        rec.put("vch_primaterno", rs.getString("vch_primaterno"));
	        rec.put("vch_prinombre", rs.getString("vch_prinombre"));
	        rec.put("chr_pridni", rs.getString("chr_pridni"));
	        rec.put("vch_prifechamat", rs.getString("vch_prifechamat"));
	        rec.put("vch_pridireccion", rs.getString("vch_pridireccion"));
	        rec.put("vch_pritelefono", rs.getString("vch_pritelefono"));
	        rec.put("chr_prigrado", rs.getString("chr_prigrado"));
	        rec.put("chr_priseccion", rs.getString("chr_priseccion"));
	        lista.add(rec);
	      }
	      rs.close();
	      pstm.close();
	    } catch (SQLException e) {
	      throw new RuntimeException(e.getMessage());
	    } catch (Exception e) {
	      e.printStackTrace();
	      String msg = "Error en el proceso de validación.";
	      if (e.getMessage() != null) {
	        msg += "\n" + e.getMessage();
	      }
	      throw new RuntimeException(msg);
	    } finally {
	      try {
	        cn.close();
	      } catch (Exception e) {
	      }
	    }

	    return lista;
    
  
 }
  
  
  @Override
  public List<Map<String, ?>> obtenerSecundaria(String paterno, String materno, String nombres) {
	  List<Map<String, ?>> lista = new ArrayList<>();
	    Connection cn = null;
	    paterno +="%";
	    materno +="%";
	    nombres +="%";
	    try {
	      cn = AccesoDB.getConnection();
	      
	      String sql = "select chr_seccodigo, vch_secpaterno, "
                  + "vch_secmaterno, vch_secnombre, "
                  + "chr_secdni, vch_secfechamat, "
                  + "vch_secdireccion, vch_sectelefono, chr_secgrado, "
                  + "chr_secseccion "
                  + "from secundaria "
                  + "where vch_secpaterno like ? "
                  + "and vch_secmaterno like ? "
                  + "and vch_secnombre like ?";
	      PreparedStatement pstm = cn.prepareStatement(sql);
	      pstm.setString(1, paterno);
	      pstm.setString(2, materno);
	      pstm.setString(3, nombres);
	      ResultSet rs = pstm.executeQuery();
	      while(rs.next()){
	        Map<String,Object> rec = new HashMap<>();
	        rec.put("chr_seccodigo", rs.getString("chr_seccodigo"));
	        rec.put("vch_secpaterno", rs.getString("vch_secpaterno"));
	        rec.put("vch_secmaterno", rs.getString("vch_secmaterno"));
	        rec.put("vch_secnombre", rs.getString("vch_secnombre"));
	        rec.put("chr_secdni", rs.getString("chr_secdni"));
	        rec.put("vch_secfechamat", rs.getString("vch_secfechamat"));
	        rec.put("vch_secdireccion", rs.getString("vch_secdireccion"));
	        rec.put("vch_sectelefono", rs.getString("vch_sectelefono"));
	        rec.put("chr_secgrado", rs.getString("chr_secgrado"));
	        rec.put("chr_secseccion", rs.getString("chr_secseccion"));
	        lista.add(rec);
	      }
	      rs.close();
	      pstm.close();
	    } catch (SQLException e) {
	      throw new RuntimeException(e.getMessage());
	    } catch (Exception e) {
	      e.printStackTrace();
	      String msg = "Error en el proceso de validación.";
	      if (e.getMessage() != null) {
	        msg += "\n" + e.getMessage();
	      }
	      throw new RuntimeException(msg);
	    } finally {
	      try {
	        cn.close();
	      } catch (Exception e) {
	      }
	    }

	    return lista;
    
  
 }
  
 /* @Override
  public List<ClienteBean> readForCriteria(ClienteBean bean) {
    List<ClienteBean> lista = new ArrayList<>();
    Connection cn = null;
    try {
      cn = AccesoDB.getConnection();
      String sql = "select chr_cliecodigo, vch_cliepaterno, "
              + "vch_cliematerno, vch_clienombre, "
              + "chr_cliedni, vch_clieciudad, "
              + "vch_cliedireccion, vch_clietelefono, vch_clieemail "
              + "from cliente "
              + "where vch_cliepaterno like ? "
              + "and vch_cliematerno like ? "
              + "and vch_clienombre like ?";
      PreparedStatement pstm = cn.prepareStatement(sql);
      pstm.setString(1, bean.getPaterno() + "%");
      pstm.setString(2, bean.getMaterno() + "%");
      pstm.setString(3, bean.getNombre() + "%");
      ResultSet rs = pstm.executeQuery();
      while (rs.next()) {
        ClienteBean cliente = getBean(rs);
        lista.add(cliente);
      }
      rs.close();
      pstm.close();
    } catch (SQLException e) {
      throw new RuntimeException(e.getMessage());
    } catch (Exception e) {
      String mensaje = "Se ha producido un error, intentelo mas tarde.";
      if (e.getMessage() != null && !e.getMessage().isEmpty()) {
        mensaje += (" " + e.getMessage());
      }
      throw new RuntimeException(mensaje);
    } finally {
      try {
        cn.close();
      } catch (Exception e) {
      }
    }
    return lista;
  }*/
 /* 
  private ClienteBean getBean(ResultSet rs) throws SQLException {
	    ClienteBean bean = new ClienteBean();
	    bean.setCodigo(rs.getString("chr_cliecodigo"));
	    bean.setPaterno(rs.getString("vch_cliepaterno"));
	    bean.setMaterno(rs.getString("vch_cliematerno"));
	    bean.setNombre(rs.getString("vch_clienombre"));
	    bean.setDni(rs.getString("chr_cliedni"));
	    bean.setCiudad(rs.getString("vch_clieciudad"));
	    bean.setDireccion(rs.getString("vch_cliedireccion"));
	    bean.setTelefono(rs.getString("vch_clietelefono"));
	    bean.setEmail(rs.getString("vch_clieemail"));
	    return bean;
	  }*/

}
