package pe.egcc.eurekaapp.dao.espec;

import pe.egcc.eurekaapp.domain.SucursalBean;

/**
 *
 * @author Gustavo Coronel
 */
public interface SucursalDaoCrud extends AbstractCrud<SucursalBean>{
  
}
