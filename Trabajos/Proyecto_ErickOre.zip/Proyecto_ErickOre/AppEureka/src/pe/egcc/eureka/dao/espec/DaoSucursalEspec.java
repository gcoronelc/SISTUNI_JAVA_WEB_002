package pe.egcc.eureka.dao.espec;

import pe.egcc.eureka.domain.Sucursal;

/**
 *
 * @author Gustavo Coronel
 */
public interface DaoSucursalEspec extends DaoCrudEspec<Sucursal>{



        
}
