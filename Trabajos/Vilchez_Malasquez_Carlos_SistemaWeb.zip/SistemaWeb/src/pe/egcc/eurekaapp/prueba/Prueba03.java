package pe.egcc.eurekaapp.prueba;

import com.sun.xml.internal.ws.util.StringUtils;

/**
 *
 * @author Gustavo Coronel
 */
public class Prueba03 {
  
  public static void main(String[] args) {
    String dato;
    dato = String.format("%05d", 50);
    System.out.println(dato);
    
    

  }
}
