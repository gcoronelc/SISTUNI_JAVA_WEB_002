package pe.egcc.eureka.domain;

/**
 *
 * @author Gustavo Coronel
 */
public class Sucursal {
  
}
