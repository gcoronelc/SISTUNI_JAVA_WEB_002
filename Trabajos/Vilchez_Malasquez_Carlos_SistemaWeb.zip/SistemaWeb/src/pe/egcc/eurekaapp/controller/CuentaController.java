package pe.egcc.eurekaapp.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.jasper.tagplugins.jstl.core.Out;

import com.google.gson.Gson;

import pe.egcc.eurekaapp.domain.AdministradorBean;
import pe.egcc.eurekaapp.domain.ClienteBean;
import pe.egcc.eurekaapp.domain.EmpleadoBean;
import pe.egcc.eurekaapp.service.ClienteService;
import pe.egcc.eurekaapp.service.CuentaService;

@WebServlet({ "/Deposito","/MatPrimaria", "/MatSecundaria","/Retiro", "/Transferencia", 
  "/TraerMovimientos1","/TraerClientes","/TraerMovimientos2" })
public class CuentaController extends HttpServlet {
  private static final long serialVersionUID = 1L;
  

  protected void service(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    String path = request.getServletPath();
    switch (path) {
    case "/Deposito":
      //deposito(request, response);
      break;
    case "/MatPrimaria":
    	matprimaria(request, response);
    break;
    case "/MatSecundaria":
    	matsecundaria(request, response);
    break;
    case "/TraerMovimientos1":
      traerMovimientos1(request, response);
      break;
    case "/TraerClientes":
        traerClientes(request, response);
        break;   

    case "/TraerMovimientos2":
      traerMovimientos2(request, response);
      break;
    }
  }

  private void traerMovimientos2(HttpServletRequest request, 
    HttpServletResponse response) 
    throws IOException, ServletException {
	// Datos
	    String paterno = request.getParameter("paterno");
	    String materno = request.getParameter("materno");
	    String nombres = request.getParameter("nombres");
	    
	    // Proceso
	    CuentaService service = new CuentaService();
	    
	    List<Map<String, ?>> movimientos;
	    
	    
	    //movimientos = service.obtenerMovimientos(cuenta);
	     movimientos = service.obtenerSecundaria(paterno,materno,nombres);
	    
	    // Forward
	    request.setAttribute("movimientos", movimientos);
	    RequestDispatcher rd;
	    rd = request.getRequestDispatcher("showSecundaria.jsp");
	    rd.forward(request, response);
  }


  private void traerMovimientos1(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // Datos
    String paterno = request.getParameter("paterno");
    String materno = request.getParameter("materno");
    String nombres = request.getParameter("nombres");
    
    // Proceso
    CuentaService service = new CuentaService();
    
    List<Map<String, ?>> movimientos;
    
    
    //movimientos = service.obtenerMovimientos(cuenta);
     movimientos = service.obtenerClientes(paterno,materno,nombres);
    
    // Forward
    request.setAttribute("movimientos", movimientos);
    RequestDispatcher rd;
    rd = request.getRequestDispatcher("showMovimientos.jsp");
    rd.forward(request, response);

  }
  
  private void traerClientes(HttpServletRequest request, HttpServletResponse response)
	      throws ServletException, IOException {
	    // Datos
	    /*String pacliente = request.getParameter("pacliente");
	    // Proceso
	    CuentaService service = new CuentaService();
	    List<Map<String, ?>> movimientos;
	    movimientos = service.obtenerMovimientos(pacliente);
	    // Forward
	    request.setAttribute("movimientos", movimientos);
	    RequestDispatcher rd;
	    rd = request.getRequestDispatcher("showMovimientos.jsp");
	    rd.forward(request, response);*/
	// Datos
	    ClienteBean bean = new ClienteBean();
	    ClienteService cliservice = new ClienteService();
	    bean.setPaterno(request.getParameter("paterno"));
	    bean.setMaterno(request.getParameter("materno"));
	    bean.setNombre(request.getParameter("nombre"));
	    
	    // Procesar
	    List<ClienteBean> lista = cliservice.traerClientes(bean);
	    
	 // Forward
	    request.setAttribute("climovimientos", lista);//<-------------
	    RequestDispatcher rd;
	    rd = request.getRequestDispatcher("showClietes.jsp");
	    rd.forward(request, response);
	    /*
	    Mensaje mensaje;
	    if(lista.isEmpty()){
	    	mensaje = new Mensaje(-50, "No hay coincidencias");
	    }else{
	    	Gson gson = new Gson();
	    	mensaje = new Mensaje(1,gson.toJson(lista));
	    }
	    
	    responseClient.response(request, response, mensaje);*/

	  }

  private void deposito(HttpServletRequest request, HttpServletResponse response) throws IOException {
    /*String texto;
    try {
      // Datos
      String cuenta = request.getParameter("cuenta");
      double importe = Double.parseDouble(request.getParameter("importe"));
      // Obtener datos del empleado
      HttpSession session = request.getSession();
      EmpleadoBean bean = (EmpleadoBean) session.getAttribute("usuario");
      String codEmp = bean.getCodigo();
      // Proceso
      CuentaService service = new CuentaService();
      service.registrarDeposito(cuenta, importe, codEmp);
      // Salida
      texto = "1";
    } catch (Exception e) {
      texto = "-1";
    }
    // Respuesta
    response.setContentType("text/plain");
    response.getWriter().write(texto);*/
  }
  
  private void matprimaria(HttpServletRequest request, HttpServletResponse response) throws IOException {
	    String texto;
	    try {
	      // Datos
	    	String paterno = request.getParameter("paterno");
	        String materno = request.getParameter("materno");
	        String nombres = request.getParameter("nombres");
	        String dni 	   = request.getParameter("dni");
	        String fecha   = request.getParameter("fecha");
	        String direccion = request.getParameter("direccion");
	        String telefono = request.getParameter("telefono");
	        String grado = request.getParameter("grado");
	        String seccion = request.getParameter("seccion");
	        
	        System.out.println(paterno + " " + materno
	        		+ " " + nombres + " " + dni + " " + fecha
	        		+ " " + direccion + " " + telefono + " " + grado
	        		+ " " + seccion);
	      
	     
	      
	      // Obtener datos del empleado
	      HttpSession session = request.getSession();
	      //AdministradorBean bean = (AdministradorBean) session.getAttribute("usuario");
	      
	      // Proceso
	      CuentaService service = new CuentaService();
	      service.registrarDeposito(paterno, materno, nombres, dni, fecha,
	    		  					direccion, telefono, grado, seccion);
	      // Salida
	      texto = "1";
	    } catch (Exception e) {
	      texto = "-1";
	    }
	    // Respuesta
	    response.setContentType("text/plain");
	    response.getWriter().write(texto);
	  }
  
  private void matsecundaria(HttpServletRequest request, HttpServletResponse response) throws IOException {
	    String texto;
	    try {
	      // Datos
	    	String paterno = request.getParameter("paterno");
	        String materno = request.getParameter("materno");
	        String nombres = request.getParameter("nombres");
	        String dni 	   = request.getParameter("dni");
	        String fecha   = request.getParameter("fecha");
	        String direccion = request.getParameter("direccion");
	        String telefono = request.getParameter("telefono");
	        String grado = request.getParameter("grado");
	        String seccion = request.getParameter("seccion");
	        
	        System.out.println(paterno + " " + materno
	        		+ " " + nombres + " " + dni + " " + fecha
	        		+ " " + direccion + " " + telefono + " " + grado
	        		+ " " + seccion);
	      
	     
	      
	      // Obtener datos del empleado
	      HttpSession session = request.getSession();
	      //AdministradorBean bean = (AdministradorBean) session.getAttribute("usuario");
	      
	      // Proceso
	      CuentaService service = new CuentaService();
	      service.registrarSecundaria(paterno, materno, nombres, dni, fecha,
	    		  					direccion, telefono, grado, seccion);
	      // Salida
	      texto = "1";
	    } catch (Exception e) {
	      texto = "-1";
	    }
	    // Respuesta
	    response.setContentType("text/plain");
	    response.getWriter().write(texto);
	  }

}
