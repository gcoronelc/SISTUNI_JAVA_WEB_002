package pe.egcc.eurekaapp.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import pe.egcc.eurekaapp.dao.espec.AdministradorDaoCrud;
import pe.egcc.eurekaapp.dao.espec.EmpleadoDaoCrud;
import pe.egcc.eurekaapp.db.AccesoDB;
import pe.egcc.eurekaapp.domain.AdministradorBean;
import pe.egcc.eurekaapp.domain.EmpleadoBean;

/**
 *
 * @author Gustavo Coronel
 */
public class AdministradorDaoImpl implements AdministradorDaoCrud {

  @Override
  public AdministradorBean validar(String usuario, String clave) {
	AdministradorBean bean = null;
    Connection cn = null;
    try {
      cn = AccesoDB.getConnection();
      /*String sql = "select chr_emplcodigo, vch_emplpaterno, "
              + "vch_emplmaterno, vch_emplnombre, "
              + "vch_emplciudad, vch_empldireccion, "
              + "vch_emplusuario "
              + "from empleado "
              + "where vch_emplusuario = ? "
              + "and vch_emplclave = ? ";*/
      String sql = "select CHR_ADMCODIGO, " 
              +"VCH_ADMPATERNO, VCH_ADMMATERNO, " 
              +"VCH_ADMNOMBRE, VCH_ADMCIUDAD, " 
              +"VCH_ADMDIRECCION, VCH_ADMUSUARIO, " 
              +"VCH_ADMCLAVE "
              +"from ADMINISTRADOR "
              +"where VCH_ADMUSUARIO = ? "
              +"and VCH_ADMCLAVE = ? ";
      PreparedStatement pstm = cn.prepareStatement(sql);
      pstm.setString(1, usuario);
      pstm.setString(2, clave);
      ResultSet rs = pstm.executeQuery();
      if(rs.next()){
        bean = new AdministradorBean();
        bean.setCodigo(rs.getString("CHR_ADMCODIGO"));
        bean.setPaterno(rs.getString("VCH_ADMPATERNO"));
        bean.setMaterno(rs.getString("VCH_ADMMATERNO"));
        bean.setNombre(rs.getString("VCH_ADMNOMBRE"));
        bean.setCiudad(rs.getString("VCH_ADMCIUDAD"));
        bean.setDireccion(rs.getString("VCH_ADMDIRECCION"));
        bean.setUsuario(rs.getString("VCH_ADMUSUARIO"));
      }
      rs.close();
      pstm.close();
    } catch (SQLException e) {
      throw new RuntimeException(e.getMessage());
    } catch (Exception e) {
      e.printStackTrace();
      String msg = "Error en el proceso de validación.";
      if (e.getMessage() != null) {
        msg += "\n" + e.getMessage();
      }
      throw new RuntimeException(msg);
    } finally {
      try {
        cn.close();
      } catch (Exception e) {
      }
    }
    return bean;
  }

  @Override
  public AdministradorBean traerPorCodigo(String codigo) {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }

  @Override
  public List<AdministradorBean> taerLista(AdministradorBean bean) {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }

  @Override
  public void insertar(AdministradorBean bean) {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }

  @Override
  public void actualizar(AdministradorBean bean) {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }

  @Override
  public void eliminar(String codigo) {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }

@Override
public List<AdministradorBean> taerTodo() {
	// TODO Auto-generated method stub
	return null;
}

}
